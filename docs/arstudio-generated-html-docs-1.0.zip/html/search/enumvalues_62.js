var searchData=
[
  ['bitmap',['BITMAP',['../dd/df8/classWorkspace_1_1Item.html#a8b3aefd536695ab1e6f21d50031d714daed1e2b1658fafe7fe07ea1ac60995357',1,'Workspace::Item']]]
];
