var searchData=
[
  ['vcap',['vcap',['../de/dfe/classProcessingDialog.html#a4d199dfd3e00fe9cec84e8d763a9d4fb',1,'ProcessingDialog']]],
  ['vsplitter',['vSplitter',['../db/d6d/classCore.html#a676d3c3ca0e6e2395e5a324ff5fd9dd1',1,'Core']]]
];
