var searchData=
[
  ['file_5fname_5flabel',['file_name_label',['../de/dfe/classProcessingDialog.html#aa7859ed2016ffb841f5200d8a27bbc85',1,'ProcessingDialog']]],
  ['frames_5fcount_5flabel',['frames_count_label',['../de/dfe/classProcessingDialog.html#a28b8184009eeb1206f5cc673ab40ef7c',1,'ProcessingDialog']]]
];
