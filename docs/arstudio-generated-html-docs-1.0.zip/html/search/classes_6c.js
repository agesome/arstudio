var searchData=
[
  ['logger',['Logger',['../db/d67/classLogger.html',1,'']]]
];
