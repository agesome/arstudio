var searchData=
[
  ['newframe',['newFrame',['../d3/d1f/classTimeLineModel.html#a39fefda6269599af707c8d112eef8594',1,'TimeLineModel']]]
];
