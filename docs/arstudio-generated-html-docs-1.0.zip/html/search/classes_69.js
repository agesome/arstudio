var searchData=
[
  ['iabstractalgorithm',['IAbstractAlgorithm',['../da/df8/classIAbstractAlgorithm.html',1,'']]],
  ['item',['Item',['../dd/df8/classWorkspace_1_1Item.html',1,'Workspace']]]
];
