var searchData=
[
  ['camera',['CAMERA',['../dd/df8/classWorkspace_1_1Item.html#a8b3aefd536695ab1e6f21d50031d714daeca55d0de119639480aaca8216152a4a',1,'Workspace::Item']]]
];
