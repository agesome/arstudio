var searchData=
[
  ['dummy',['dummy',['../d2/de6/classWorkspace_1_1boost_1_1shared__ptr.html#a45749a421c5d1e241f81cb0a5c1bd885',1,'Workspace::boost::shared_ptr']]]
];
