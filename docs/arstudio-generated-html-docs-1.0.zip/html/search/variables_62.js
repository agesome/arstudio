var searchData=
[
  ['b',['b',['../d2/d37/classPoint3d.html#a0f71883e690eb4ea5c483595e0a4bbb2',1,'Point3d']]],
  ['bitmap',['bitmap',['../d3/d19/classBitmap.html#a9a922fd970fe2517eab475725f8cd31d',1,'Bitmap']]],
  ['branchremovedcallback',['branchRemovedCallback',['../d0/d09/classWorkspace_1_1Repository.html#aa1e63961b2b2d0256e7f01cd871112c3',1,'Workspace::Repository']]]
];
