var searchData=
[
  ['b',['b',['../d2/d37/classPoint3d.html#a0f71883e690eb4ea5c483595e0a4bbb2',1,'Point3d']]],
  ['bitmap',['Bitmap',['../d3/d19/classBitmap.html',1,'Bitmap'],['../dd/df8/classWorkspace_1_1Item.html#a8b3aefd536695ab1e6f21d50031d714daed1e2b1658fafe7fe07ea1ac60995357',1,'Workspace::Item::BITMAP()'],['../d3/d19/classBitmap.html#a9a922fd970fe2517eab475725f8cd31d',1,'Bitmap::bitmap()']]],
  ['bitmap_2ehpp',['Bitmap.hpp',['../d0/de6/Bitmap_8hpp.html',1,'']]],
  ['branchremovedcallback',['branchRemovedCallback',['../d0/d09/classWorkspace_1_1Repository.html#aa1e63961b2b2d0256e7f01cd871112c3',1,'Workspace::Repository']]]
];
