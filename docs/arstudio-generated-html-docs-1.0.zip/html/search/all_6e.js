var searchData=
[
  ['newbranchcallback',['newBranchCallback',['../d0/d09/classWorkspace_1_1Repository.html#a2863fa131eb3d02e5a9377f66b6c22ce',1,'Workspace::Repository']]],
  ['newframe',['newFrame',['../d3/d1f/classTimeLineModel.html#a39fefda6269599af707c8d112eef8594',1,'TimeLineModel']]],
  ['newsequencecallback',['newSequenceCallback',['../d0/d09/classWorkspace_1_1Repository.html#a199a7c6837ada168f91af056b5902d11',1,'Workspace::Repository']]],
  ['nsca',['nSca',['../dc/d49/classWindow3D.html#af3e6b2349734f0da0e689ded4cb1e49f',1,'Window3D']]]
];
