var searchData=
[
  ['type',['type',['../dd/df8/classWorkspace_1_1Item.html#a8b3aefd536695ab1e6f21d50031d714d',1,'Workspace::Item']]]
];
