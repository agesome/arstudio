var searchData=
[
  ['g',['g',['../d2/d37/classPoint3d.html#afc17047f743be4ec8e51c7a22c87239d',1,'Point3d']]]
];
