var searchData=
[
  ['quit',['quit',['../db/d6d/classCore.html#a7d6ca7943e0aa8d8d33a151fdc131f6e',1,'Core']]]
];
