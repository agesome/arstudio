var searchData=
[
  ['x',['x',['../d2/d37/classPoint3d.html#aebdfdfaeb02b3cc834eacb7a17a88e5d',1,'Point3d']]],
  ['xrot',['xRot',['../dc/d49/classWindow3D.html#a2fc14352a900330444ac6cb90ce040bd',1,'Window3D']]]
];
