var searchData=
[
  ['end_5fframe_5fspin',['end_frame_spin',['../df/dbb/classarstudio_1_1ProcessingDialog.html#a8fcac34f2fe788fe78c0d16dfcc5dc26',1,'arstudio::ProcessingDialog']]]
];
