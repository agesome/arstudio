var searchData=
[
  ['logger',['Logger',['../d3/d66/classarstudio_1_1Logger.html',1,'arstudio']]]
];
