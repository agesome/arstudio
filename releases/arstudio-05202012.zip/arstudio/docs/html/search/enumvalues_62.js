var searchData=
[
  ['bitmap',['BITMAP',['../d0/d44/classarstudio_1_1Item.html#abdac6c71152aa147c2ffc42db4da1474a66bb21d66c7a41937af8f11885218dc2',1,'arstudio::Item']]]
];
