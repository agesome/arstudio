var searchData=
[
  ['new_5fbranch_5fcb',['new_branch_cb',['../d7/d73/classarstudio_1_1Repository.html#a9ca6dd12f2deffb3585a84a6cb466a49',1,'arstudio::Repository']]],
  ['new_5fframe',['new_frame',['../d0/df6/classarstudio_1_1TimeLineModel.html#ad8e2eb0ffa2959c364b5b8c1f51df4ea',1,'arstudio::TimeLineModel']]],
  ['new_5fsequence_5fcb',['new_sequence_cb',['../d7/d73/classarstudio_1_1Repository.html#a2a2da43e7f433d611771b1177e99e675',1,'arstudio::Repository']]],
  ['next_5fbutton',['next_button',['../de/d92/classarstudio_1_1TimeLine.html#ae61aa96232e4e69716db2baec9e0880f',1,'arstudio::TimeLine']]],
  ['next_5fbutton_5fpressed',['next_button_pressed',['../de/d92/classarstudio_1_1TimeLine.html#a92a3a3ab473bd5efead55759ee82431c',1,'arstudio::TimeLine']]],
  ['next_5fframe',['next_frame',['../d0/df6/classarstudio_1_1TimeLineModel.html#a04b54fe95e0c53c4821bbd96b1e11a21',1,'arstudio::TimeLineModel::next_frame()'],['../dd/de0/classarstudio_1_1IVideoSource.html#ae3923d5fd9c114b8732794fb89dcffcc',1,'arstudio::IVideoSource::next_frame()'],['../d4/df6/classarstudio_1_1VideoHelper.html#a9a3cfa21a8bb574920941989109ca003',1,'arstudio::VideoHelper::next_frame()'],['../d5/d8c/classarstudio_1_1VideoSourceKinvideo.html#a45253bcc9da22b20e7b176b5126f28ca',1,'arstudio::VideoSourceKinvideo::next_frame()'],['../d1/d4d/classarstudio_1_1VideoSourceOpenCV.html#a8ac81d8ff34b6c59cfb6aa8f52036bce',1,'arstudio::VideoSourceOpenCV::next_frame()']]]
];
